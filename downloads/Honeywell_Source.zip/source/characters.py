"""Original chibi staff and a consistent serialized aerospace component."""
import bpy, math
from common import cube, sphere, cyl, rod, mesh, empty, mat


def _stroke(name, points, material, radius=.012, parent=None):
    cu=bpy.data.curves.new(name,'CURVE'); cu.dimensions='3D'; cu.bevel_depth=radius; cu.bevel_resolution=2
    sp=cu.splines.new('POLY'); sp.points.add(len(points)-1)
    for p,co in zip(sp.points,points): p.co=(*co,1)
    ob=bpy.data.objects.new(name,cu); bpy.context.collection.objects.link(ob)
    ob.data.materials.append(material if not isinstance(material,str) else mat(material))
    if parent: ob.parent=parent
    return ob


def _hair_lock(name,x,z,width,height,depth,hair,parent,tilt=0):
    # A pointed, swept triangular prism with a raised center facet. All front
    # faces have outward -Y normals so studio lighting retains the brown color.
    pts=[(-width*.52,.018,height*.48), (width*.48,.022,height*.43),
         (width*.18,-depth,-height*.50), (-width*.02,-depth*.63,height*.13),
         (-width*.52,.13,height*.48), (width*.48,.13,height*.43),
         (width*.18,.06,-height*.50)]
    faces=[(0,2,3),(2,1,3),(1,0,3),(4,5,6),
           (0,1,5,4),(1,2,6,5),(2,0,4,6)]
    ob=mesh(name,pts,faces,hair,parent)
    ob.location=(x,-.273,z);ob.rotation_euler.y=tilt
    return ob


def character(name,loc=(0,0,0),role='technician',yaw=0):
    root=empty(name,loc);root.rotation_euler.z=yaw
    female=role=='engineer'
    skin_colors={'technician':(.91,.66,.44,1),'engineer':(.86,.59,.43,1),'buyer':(.62,.37,.22,1),'receiving':(.96,.72,.54,1)}
    skin=mat('Skin '+role,skin_colors.get(role,skin_colors['technician']))
    hair=mat('Hair '+role,{'technician':(.18,.065,.020,1),'engineer':(.11,.042,.014,1),'buyer':(.047,.025,.011,1),'receiving':(.22,.077,.020,1)}.get(role,(.22,.09,.033,1)))
    white='white'; uniform='navy' if role in ['technician','buyer'] else 'white'
    # Shoes, tapered trouser legs, belt, and tailored jacket remain readable at wide shots.
    for side,x in [('left',-.145),('right',.145)]:
        cube(name+' '+side+' shoe',(x,-.075,.105),(.245,.38,.19),'ink',.06,root)
        cube(name+' '+side+' outsole',(x,-.08,.028),(.25,.38,.046),'navy',.012,root)
        cube(name+' '+side+' trouser',(x,.018,.46),(.215,.25,.61),'navy',.042,root)
    body=cube(name+' fitted uniform',(0,0,1.11),(.60,.33,.69),uniform,.11,root)
    cube(name+' belt',(0,-.005,.795),(.54,.34,.065),'ink',.024,root)
    cube(name+' belt clasp',(0,-.185,.797),(.09,.025,.05),'silver',.012,root)
    # Front seam and lapels form intentional apparel, not a stacked sphere body.
    cube(name+' placket',(0,-.173,1.13),(.026,.022,.49),'blue' if role=='technician' else 'navy',.006,root)
    for x in [-.115,.115]:
        lapel=cube(name+' collar',(x,-.183,1.417),(.18,.034,.09),'white',.011,root)
        lapel.rotation_euler.y=math.copysign(.28,x)
    if role=='technician':
        cube(name+' breast pocket',(-.16,-.176,1.25),(.155,.026,.13),'blue',.015,root)
        cube(name+' pocket orange marker',(-.16,-.197,1.29),(.08,.008,.025),'orange',.004,root)
    else:
        cube(name+' badge',( .16,-.187,1.25),(.12,.016,.16),'white',.009,root)
        cube(name+' badge stripe',(.16,-.201,1.295),(.09,.008,.028),'blue',.003,root)
        if role=='buyer':
            cube(name+' shirt insert',(0,-.188,1.36),(.16,.025,.19),'white',.015,root)
            tie=mesh(name+' navy tie',[(-.023,-.209,1.4),(.023,-.209,1.4),(.045,-.209,1.22),(0,-.209,1.17),(-.045,-.209,1.22)],[(0,1,2,3,4)],'blue',root)
    cyl(name+' neck',(0,0,1.525),.125,.20,skin,root)
    head=empty(name+' head pivot',(0,0,1.62),root)
    sphere(name+' sculpted head',(0,-.015,.35),(.465,.345,.47),skin,head,segments=24,rings=14)
    # Small ears and subtle cheek coloring.
    for sign in [-1,1]:
        sphere(name+' ear',(sign*.448,-.015,.31),(.073,.07,.11),skin,head,segments=12,rings=8)
        sphere(name+' inner ear',(sign*.470,-.075,.31),(.035,.016,.058),mat('Ear soft '+role,(.77,.39,.30,1)),head)
        sphere(name+' cheek',(sign*.285,-.305,.215),(.077,.017,.035),mat('Blush '+role,(.87,.43,.35,1)),head)
    for side,x in [('left',-.177),('right',.177)]:
        # Distinct silhouettes with layered iris, pupil and two reflective dots.
        sphere(name+' '+side+' eye white',(x,-.325,.38),(.113,.032,.134),'white',head,segments=24,rings=12)
        sphere(name+' '+side+' iris',(x,-.353,.378),(.061,.018,.088),mat('Iris warm',(.18,.10,.048,1)),head,segments=20,rings=12)
        sphere(name+' '+side+' pupil',(x,-.368,.379),(.035,.01,.062),'ink',head,segments=16,rings=12)
        sphere(name+' '+side+' eye shine',(x-.017,-.379,.417),(.024,.007,.025),'white',head)
        sphere(name+' '+side+' small glint',(x+.021,-.379,.35),(.010,.005,.012),'white',head)
        _stroke(name+' '+side+' upper eyelash',[(x-.091,-.355,.46),(x-.03,-.365,.49),(x+.049,-.359,.486),(x+.087,-.343,.463)],hair,.012,head)
        _stroke(name+' '+side+' brow',[(x-.078,-.324,.572),(x,-.343,.593),(x+.074,-.321,.58)],hair,.017,head)
    sphere(name+' nose',(0,-.365,.247),(.052,.065,.056),skin,head,segments=12,rings=8)
    _stroke(name+' smile',[(-.074,-.334,.153),(-.04,-.345,.135),(0,-.349,.13),(.04,-.345,.138),(.071,-.334,.159)],mat('Smile',(.25,.077,.05,1)),.011,head)
    # Rear cap and multiple asymmetric facets suggest sculpted brown hair.
    sphere(name+' hair cap',(0,.04,.57),(.474,.339,.328),hair,head,segments=16,rings=8,smooth=False)
    for i,(x,z,w,h,d,tilt) in enumerate([(-.34,.67,.18,.34,.10,-.28),(-.215,.716,.25,.39,.12,-.34),(-.045,.759,.29,.38,.13,-.36),(.15,.754,.29,.34,.13,-.39),(.33,.677,.20,.33,.11,-.29)]):
        _hair_lock(name+' angular fringe '+str(i),x,z,w,h,d,hair,head,tilt)
    for sign in [-1,1]:
        cube(name+' sideburn',(sign*.413,-.099,.447),(.073,.18,.27),hair,.022,head)
    if female:
        sphere(name+' tied ponytail',(0,.375,.49),(.20,.20,.30),hair,head,segments=12,rings=8,smooth=False)
        cyl(name+' hair tie',(0,.367,.65),.14,.05,'blue',head,axis='Y')
    arms={}
    for side,sign in [('left',-1),('right',1)]:
        arm=empty(name+' '+side+' shoulder',(sign*.345,0,1.39),root)
        upper=cube(name+' '+side+' upper sleeve',(0,0,-.160),(.215,.23,.34),uniform,.075,arm)
        forearm=empty(name+' '+side+' elbow',(0,0,-.315),arm)
        cube(name+' '+side+' forearm',(0,0,-.163),(.172,.19,.345),uniform,.06,forearm)
        cube(name+' '+side+' white cuff',(0,0,-.328),(.18,.20,.074),'white',.016,forearm)
        # Each glove has a flat palm, four subtle finger seams, and a thumb.
        hand=empty(name+' '+side+' hand',(0,0,-.417),forearm)
        glove='white' if role in ['technician','receiving'] else skin
        cube(name+' '+side+' palm',(0,-.01,0),(.158,.115,.16),glove,.037,hand)
        sphere(name+' '+side+' thumb',(-sign*.083,-.05,.023),(.047,.043,.065),glove,hand,segments=12,rings=8)
        for f in range(3):
            _stroke(name+' '+side+' finger seam '+str(f),[(-.045+f*.045,-.071,-.019),(-.045+f*.045,-.071,-.064)],mat('Glove seam',(.63,.72,.74,1)) if isinstance(glove,str) else mat('Skin seam',(.62,.37,.22,1)),.0025,hand)
        arms[side+'_arm']=arm; arms[side+'_forearm']=forearm;arms[side+'_hand']=hand
    return dict(root=root,head=head,**arms)


def _id_plate(name,loc,parent,scale=1):
    p=empty(name,loc,parent)
    cube(name+' white serialized label',(0,0,0),(.29*scale,.018,.095*scale),'white',.006,p)
    cube(name+' matching blue identity stripe',(-.119*scale,-.012,0),(.029*scale,.01,.078*scale),'blue',.002,p)
    widths=[.009,.004,.013,.005,.008,.013,.004,.006,.011,.004,.007]
    x=-.090
    for i,w in enumerate(widths):
        cube(name+' barcode '+str(i),(x*scale,-.013,0),(w*scale,.009,.059*scale),'ink',.001,p);x+=w+.006
    return p


def component(name,loc=(0,0,0),parent=None):
    root=empty(name,loc,parent)
    cyl(name+' silver body',(0,0,0),.14,.64,mat('Machined component silver',(.66,.72,.74,1),metallic=.65),root,axis='X',vertices=24)
    for x in [-.285,.285]:
        cyl(name+' end flange',(x,0,0),.172,.065,'silver',root,axis='X',vertices=16)
        for a in [0,math.pi/2,math.pi,math.pi*1.5]:
            cyl(name+' flange screw',(x+(.04 if x>0 else -.04),math.cos(a)*.128,math.sin(a)*.128),.016,.018,'navy',root,axis='X',vertices=6)
    cyl(name+' blue serial band',(-.12,0,0),.144,.105,'blue',root,axis='X',vertices=24)
    cyl(name+' terminal end cap',(.342,0,0),.079,.035,'navy',root,axis='X',vertices=16)
    cyl(name+' metal terminal',(.37,0,0),.038,.025,'silver',root,axis='X',vertices=12)
    _id_plate(name+' identification plate',(.042,-.15,.014),root,.82)
    return root


def package(name,loc=(0,0,0),parent=None,open=True):
    root=empty(name,loc,parent)
    # Base lower z=0; interior is visible with component resting on navy foam.
    cube(name+' bottom',(0,0,.035),(.95,.75,.07),'kraft',.015,root)
    for x in [-.4525,.4525]: cube(name+' side wall',(x,0,.275),(.045,.75,.45),'kraft',.01,root)
    for y in [-.3525,.3525]: cube(name+' end wall',(0,y,.275),(.91,.045,.45),'kraft',.01,root)
    cube(name+' cushioning bed',(0,0,.095),(.85,.64,.075),'navy',.025,root)
    for y in [-.245,.245]: cube(name+' foam restraint',(0,y,.205),(.82,.115,.21),'navy',.033,root)
    _id_plate(name+' matched external component identity',(0,-.38,.285),root,1.2)
    lid=empty(name+' lid hinge',(0,.375,.5),root)
    cube(name+' hinged lid',(0,-.375,.024),(.98,.78,.048),'kraft',.015,lid)
    cube(name+' blue handling stripe',(-.33,-.375,.052),(.035,.68,.006),'blue',.002,lid)
    if open: lid.rotation_euler.x=-1.85
    return {'root':root,'lid':lid}
