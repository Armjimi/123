"""Assemble 30 seconds of native 1080p renders and the original soundtrack."""
from pathlib import Path
import argparse, subprocess, json

BASE=Path(__file__).resolve().parent.parent
FONT='/usr/share/fonts/truetype/open-sans/OpenSans-Semibold.ttf'

def assemble(render_fps=12,interpolate=True):
    frames=sorted((BASE/'render').glob('frame_*.png'))
    expected=round(30*render_fps)
    if len(frames)!=expected:
        raise RuntimeError(f'Expected {expected} rendered frames, found {len(frames)}')
    filters=[]
    if interpolate:
        filters.append('minterpolate=fps=24:mi_mode=mci:mc_mode=obmc:me_mode=bilat:me=epzs:search_param=16:scd=fdiff:scd_threshold=12')
        filters.append('tpad=stop_mode=clone:stop_duration=0.25')
    else: filters.append('fps=24')
    filters += [
        "drawbox=x=80:y=80:w=800:h=112:color=0x10283F@0.84:t=fill:enable='between(t,0.7,3.8)'",
        "drawbox=x=80:y=80:w=8:h=112:color=0xF3B531:t=fill:enable='between(t,0.7,3.8)'",
        f"drawtext=fontfile={FONT}:text='Honeywell Aerospace':x=112:y=99:fontsize=60:fontcolor=white:enable='between(t,0.7,3.8)'",
        "drawbox=x=80:y=914:w=385:h=95:color=0x10283F@0.86:t=fill:enable='between(t,10.9,15.0)'",
        f"drawtext=fontfile={FONT}:text='Blockchain':x=108:y=929:fontsize=53:fontcolor=white:enable='between(t,10.9,15.0)'",
        "drawbox=x=80:y=862:w=1230:h=166:color=0x10283F@0.86:t=fill:enable='gte(t,28)'",
        "drawbox=x=80:y=862:w=8:h=166:color=0xF3B531:t=fill:enable='gte(t,28)'",
        f"drawtext=fontfile={FONT}:text='Honeywell GoDirect Trade':x=112:y=878:fontsize=61:fontcolor=white:enable='gte(t,28)'",
        f"drawtext=fontfile={FONT}:text='Traceable history. Confident trading.':x=112:y=960:fontsize=40:fontcolor=0xD7ECEC:enable='gte(t,28)'",
        'format=yuv420p',
    ]
    output=BASE/'delivery'/'Honeywell_GoDirect_Trade_30s.mp4'
    cmd=['ffmpeg','-hide_banner','-y','-threads','4','-framerate',str(render_fps),'-pattern_type','glob','-i',str(BASE/'render'/'frame_*.png'),'-i',str(BASE/'delivery'/'soundtrack.wav'),'-vf',','.join(filters),'-af','loudnorm=I=-17:TP=-1.2:LRA=8','-c:v','libx264','-preset','medium','-crf','18','-c:a','aac','-b:a','192k','-ar','48000','-t','30','-movflags','+faststart',str(output)]
    subprocess.run(cmd,check=True)
    info=subprocess.check_output(['ffprobe','-v','error','-show_streams','-show_format','-of','json',str(output)],text=True)
    (BASE/'delivery'/'validation.json').write_text(info)
    return output

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--fps',type=int,default=12);p.add_argument('--no-interpolation',action='store_true')
    args=p.parse_args();print(assemble(args.fps,not args.no_interpolation))
