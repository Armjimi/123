#!/usr/bin/env python3
"""Original instrumental score and synchronized workplace sounds, 30 seconds.

Run: python audio.py [output.wav]
Dependencies: numpy, scipy. Deterministic synthesis; no downloaded samples.
"""
from pathlib import Path
import sys
import numpy as np
from scipy import signal
from scipy.io import wavfile

RATE = 48000
DURATION = 30.0
N = int(RATE * DURATION)
RNG = np.random.default_rng(230713)
music = np.zeros((N, 2), dtype=np.float64)
fx = np.zeros_like(music)


def frequency(midi):
    return 440.0 * 2.0 ** ((midi - 69.0) / 12.0)


def timeline(duration):
    return np.arange(int(round(duration * RATE))) / RATE


def add(bus, sound, at, gain=1.0, pan=0.0):
    """Equal-power stereo placement, clipping safely at the film boundaries."""
    start = int(round(at * RATE))
    count = min(len(sound), N - start)
    if count <= 0:
        return
    angle = (pan + 1.0) * np.pi / 4.0
    bus[start:start + count, 0] += sound[:count] * gain * np.cos(angle)
    bus[start:start + count, 1] += sound[:count] * gain * np.sin(angle)


def warm_key(note, duration=1.3):
    t = timeline(duration)
    f = frequency(note)
    attack = 1 - np.exp(-t / .004)
    release = np.minimum(1, np.maximum(0, (duration - t) / .08))
    # Soft felt-piano / wooden-mallet timbre: rapidly decaying upper partials.
    tone = np.sin(2 * np.pi * f * t) * np.exp(-t / .56)
    tone += .30 * np.sin(2 * np.pi * 2.001 * f * t) * np.exp(-t / .22)
    tone += .085 * np.sin(2 * np.pi * 3.004 * f * t) * np.exp(-t / .10)
    return tone * attack * release


def soft_pad(notes, duration=2.35):
    t = timeline(duration)
    envelope = np.minimum(1, t / .17) * np.minimum(1, (duration - t) / .5)
    tone = np.zeros(len(t))
    for k, note in enumerate(notes):
        f = frequency(note)
        tone += (.86 * np.sin(2 * np.pi * f * t + k * .23)
                 + .09 * np.sin(2 * np.pi * f * 2 * t))
    return envelope * tone / len(notes)


def bass(note):
    t = timeline(.65)
    f = frequency(note)
    envelope = (1 - np.exp(-t / .014)) * np.exp(-t / .22)
    envelope *= np.minimum(1, (.65 - t) / .05)
    return envelope * (np.sin(2 * np.pi * f * t) + .10 * np.sin(4 * np.pi * f * t))


def noise(duration, high=1000, low=9000):
    x = RNG.normal(size=len(timeline(duration)))
    if high:
        x = signal.sosfilt(signal.butter(2, high, fs=RATE, btype='highpass', output='sos'), x)
    if low:
        x = signal.sosfilt(signal.butter(2, low, fs=RATE, btype='lowpass', output='sos'), x)
    return x


def kick():
    t = timeline(.24)
    phase = 2 * np.pi * (52 * t + 22 * .025 * (1 - np.exp(-t / .025)))
    return np.sin(phase) * (1 - np.exp(-t / .0015)) * np.exp(-t / .06)


def brush():
    t = timeline(.16)
    return noise(.16, 1600, 6300) * (1 - np.exp(-t / .003)) * np.exp(-t / .034)


def hat():
    t = timeline(.07)
    return noise(.07, 3900, 9000) * (1 - np.exp(-t / .001)) * np.exp(-t / .014)


# Fifteen 4/4 bars, 120 BPM. Open ninth voicings and a quiet repeated theme.
progression = [
    (36, [55, 60, 64, 71]), (33, [55, 60, 64, 69]),
    (29, [53, 57, 60, 67]), (31, [55, 59, 62, 69]),
    (36, [55, 60, 64, 71]), (33, [55, 60, 64, 69]),
    (29, [53, 57, 60, 67]), (31, [55, 60, 62, 69]),
    (38, [57, 60, 65, 69]), (40, [55, 59, 64, 67]),
    (29, [53, 57, 60, 67]), (31, [55, 59, 62, 69]),
    (29, [53, 57, 60, 67]), (31, [55, 60, 62, 69]),
    (36, [55, 60, 64, 67, 71]),
]
melodies = [
    [72, 76, 79, 76], [76, 72, 69, 72], [72, 69, 67, 69], [71, 74, 79, 74],
    [72, 76, 79, 81], [79, 76, 72, 69], [72, 77, 76, 72], [74, 71, 67, 71],
    [74, 77, 81, 77], [76, 79, 76, 71], [72, 69, 65, 69], [71, 74, 79, 74],
    [77, 76, 72, 69], [74, 71, 67, 71], [72, 76, 79, 72],
]
for bar, (root, notes) in enumerate(progression):
    start = bar * 2.0
    add(music, soft_pad(notes), start, .076, -.24)
    add(music, soft_pad([n + 12 for n in notes], 2.3), start + .012, .019, .32)
    for beat in range(4):
        at = start + beat * .5
        if bar < 14:
            add(music, bass(root if beat < 2 else root + 7), at, .17 if beat % 2 == 0 else .105)
            if beat in (0, 2):
                add(music, kick(), at, .105)
            else:
                add(music, brush(), at, .028, .12)
            add(music, hat(), at + .25, .021, -.16 if beat % 2 else .16)
        # Leave air around each scene; final tonic rests for the title hold.
        if bar < 14 or beat in (0, 1):
            add(music, warm_key(melodies[bar][beat]), at + .035, .115, -.15 + beat * .1)
        if bar < 14 and beat in (1, 3):
            add(music, warm_key(notes[beat], .8), at + .25, .04, -.3)

# A supported warm cadence at 28 seconds, with bass root held underneath.
add(music, bass(36), 28.0, .16)
add(music, warm_key(60, 1.95), 28.0, .085, -.25)
add(music, warm_key(64, 1.9), 28.025, .07, .25)
add(music, warm_key(67, 1.85), 28.06, .065, .1)

# Short stereo room reflections, restrained so the tiny UI sounds stay readable.
dry = music.copy()
for delay, gain in [(.083, .085), (.147, .05), (.229, .035), (.331, .022)]:
    offset = int(delay * RATE)
    music[offset:] += dry[:-offset, ::-1] * gain


def tap(at, gain=.085, pan=.05):
    t = timeline(.06)
    x = noise(.06, 1200, 6000) * np.exp(-t / .009)
    x += .32 * np.sin(2 * np.pi * 850 * t) * np.exp(-t / .012)
    add(fx, x, at, gain, pan)


def metallic(at, gain=.09, pan=-.22):
    t = timeline(.28)
    x = sum(a * np.sin(2 * np.pi * f * t) * np.exp(-t / decay)
            for f, a, decay in [(620, 1, .075), (1191, .32, .037), (2180, .09, .019)])
    x *= 1 - np.exp(-t / .001)
    add(fx, x, at, gain, pan)


def confirm(at, note=76, gain=.065):
    add(fx, warm_key(note, .37), at, gain, .14)
    add(fx, warm_key(note + 7, .36), at + .07, gain * .65, .24)


def paper(at, duration=.38, gain=.06, pan=-.14):
    t = timeline(duration)
    x = noise(duration, 700, 6200)
    flutter = (.38 + .62 * np.sin(2 * np.pi * 13 * t) ** 2)
    envelope = np.sin(np.pi * np.arange(len(t)) / len(t)) ** 1.4
    add(fx, x * flutter * envelope, at, gain, pan)


# Sound cues follow the storyboard; each is an original synthetic workplace texture.
metallic(1.5, .075)                         # Technician's small tool contact.
metallic(3.6, .047, -.16)                  # Identification plate inspected.
tap(5.5, .06)
for at, note in [(6.1, 72), (7.0, 74), (7.9, 76), (8.8, 79)]:
    tap(at, .038)
    add(fx, warm_key(note, .35), at + .045, .044, .16)
tap(10.3, .065)                            # Authorized badge reader.
confirm(10.36, 72, .055)
tap(11.2, .058)                            # New record submitted.
for at in [12.0, 12.5, 13.0]:
    confirm(at, 76, .052)                  # Three network confirmations.
tap(14.1, .066)
confirm(14.16, 79, .056)                   # New block joins retained history.
tap(17.2, .062)                            # Buyer selects familiar part.
tap(19.0, .036)                            # History reviewed.
paper(21.4, .23, .032)                     # Related document opens.
tap(22.5, .06)
confirm(22.56, 76, .077)                   # Single order confirmation.
paper(23.8, .58, .082)                     # Protective packing material.
paper(25.0, .42, .076)                     # Carton closes, label attaches.
tap(25.18, .045, -.2)
paper(26.4, .23, .045, .18)                # Package reaches receiving counter.
tap(26.43, .043, .18)
tap(27.0, .046)
confirm(27.08, 72, .066)                   # Identification matched to record.
add(fx, warm_key(79, .7), 27.8, .038, .10)  # Subtle positive accent on nod.

# Low-level ventilation/room bed. No voices, alarms, or engine roar.
room = RNG.normal(size=N)
room = signal.sosfilt(signal.butter(2, [85, 850], fs=RATE, btype='bandpass', output='sos'), room)
room *= .0018
fx[:, 0] += room
fx[:, 1] += np.roll(room, 37) * .96

mix = music + fx
# Smooth program fade and final musical resolution, no hard start or tail click.
fade_in = int(.08 * RATE)
fade_out = int(.4 * RATE)
mix[:fade_in] *= np.linspace(0, 1, fade_in)[:, None]
mix[-fade_out:] *= np.linspace(1, 0, fade_out)[:, None] ** 1.2
# Transparent gain and a protective peak ceiling preserve the transients.
target_rms = 10 ** (-18.0 / 20)
mix *= target_rms / np.sqrt(np.mean(mix ** 2))
peak_limit = 10 ** (-1.0 / 20)
# Only attenuate the mix if the crest factor calls for it; do not hard-clip.
peak = float(np.max(np.abs(mix)))
if peak > peak_limit:
    mix *= peak_limit / peak
destination = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(__file__).resolve().parents[1] / 'delivery' / 'soundtrack.wav'
destination.parent.mkdir(parents=True, exist_ok=True)
wavfile.write(destination, RATE, np.round(mix * 32767).astype(np.int16))
print(f'{destination}: {DURATION:g}s, {RATE}Hz, stereo PCM16; '
      f'peak {20*np.log10(np.max(np.abs(mix))):.2f} dBFS; '
      f'RMS {20*np.log10(np.sqrt(np.mean(mix**2))):.2f} dBFS')
