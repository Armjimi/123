"""Compact, readable miniature workplaces for the Honeywell opening film.

All geometry is local to its returned root; the central tabletop is 3 x 1.3 m
and centered at z=1.15.  Screens and people are supplied by build_film.py.
"""
import math
from common import empty, cube, sphere, cyl, rod, mesh, area


def _bench(root, name='Work bench', color='teal', drawers=True):
    top = cube(name + ' matte top', (0, 0, 1.15), (3, 1.3, .12), 'white', .045, root)
    cube(name + ' apron', (0, 0, .98), (2.85, 1.12, .22), color, .03, root)
    for x in (-1.25, 1.25):
        for y in (-.48, .48):
            cube(name + ' square leg', (x, y, .47), (.09, .09, .94), 'navy', .012, root)
    cube(name + ' low shelf', (0, 0, .29), (2.65, 1.0, .08), 'silver', .015, root)
    if drawers:
        for x in (-.92, .0, .92):
            cube(name + ' drawer front', (x, -.571, .985), (.82, .045, .16), color, .012, root)
            cube(name + ' drawer handle', (x, -.607, .99), (.28, .025, .025), 'navy', .005, root)
    return top


def _floor(root, width=16, depth=14, color='floor'):
    cube('Miniature factory floor', (0, 0, -.10), (width, depth, .2), color, .04, root)
    # Painted safety routes flank the action and leave the central table clear.
    for x in (-2.6, 2.6):
        cube('Yellow walking lane', (x, 0, .009), (.055, depth - 1, .012), 'yellow', .002, root)
    for y in (-3.6, 3.05):
        cube('Yellow transverse bay mark', (0, y, .011), (5.2, .055, .015), 'yellow', .002, root)
    for x in (-5.5, 5.5):
        cube('Concrete expansion seam', (x, 0, .004), (.015, depth, .006), 'silver', 0, root)


def _industrial_back(root, y=6.9, width=16, height=5.8):
    cube('Hangar lower wall', (0, y, .9), (width, .18, 1.8), 'pale', .025, root)
    cube('Daylit clerestory field', (0, y + .07, 3.55), (width, .10, 3.5), 'sky', .012, root)
    for x in (-7.5, -5, -2.5, 0, 2.5, 5, 7.5):
        cube('Tall blue structural column', (x, y - .09, height / 2), (.13, .26, height), 'blue', .015, root)
    for z in (1.78, 3.48, 5.30):
        cube('Industrial window mullion', (0, y - .15, z), (width, .09, .085), 'navy', .008, root)
    cube('Overhead blue beam', (0, y - .34, height), (width, .30, .23), 'blue', .016, root)
    # Side columns and roof crossmembers reveal a full-size hangar volume.
    for yside in (1.8, 4.35):
        cube('Left hangar column', (-7.55, yside, 2.85), (.18, .22, 5.7), 'blue', .015, root)
        cube('Roof span', (0, yside, 5.7), (15.2, .16, .17), 'blue', .015, root)
    cube('Left low wall', (-7.75, 3.85, .62), (.15, 6.0, 1.24), 'pale', .015, root)


def _plane(root, loc=(0, 4.1, 1.45), scale=1.0, name='White maintenance jet'):
    """A recognisable nose-forward twin-engine airplane, about 7.4m wide."""
    p = empty(name, loc, root)
    p.scale = (scale, scale, scale)
    sphere(name + ' fuselage', (0, 0, 0), (.46, 2.15, .43), 'white', p, 24, 12)
    sphere(name + ' nose', (0, -1.82, -.035), (.37, .55, .32), 'white', p)
    sphere(name + ' dark cockpit glazing', (0, -1.12, .29), (.35, .55, .16), 'navy', p)
    # The blue canopy divider makes the cockpit read in miniature.
    cube(name + ' cockpit central frame', (0, -1.22, .407), (.035, .63, .024), 'white', .007, p)
    for side in (-1, 1):
        verts = [(side*.30,-.65,0), (side*3.7,.65,-.035),
                 (side*3.7,1.10,-.035), (side*.36,1.12,.0),
                 (side*.30,-.65,.065), (side*3.7,.65,.03),
                 (side*3.7,1.10,.03), (side*.36,1.12,.065)]
        mesh(name + ' swept wing', verts, [(0,1,2,3),(4,7,6,5),(0,4,5,1),(1,5,6,2),(2,6,7,3)], 'white', p)
        cyl(name + ' engine nacelle', (side*1.27, .25, -.24), .25, .85, 'white', p, 'Y', 20)
        cyl(name + ' engine inlet', (side*1.27, -.18, -.24), .20, .025, 'navy', p, 'Y', 20)
        cyl(name + ' engine fan', (side*1.27, -.198, -.24), .10, .027, 'silver', p, 'Y')
        sphere(name + ' wingtip marker', (side*3.58, .96, .04), (.055,.11,.045), 'red' if side < 0 else 'mint', p)
        tail = cube(name + ' horizontal stabilizer', (side*.85, 1.60, .19), (1.5,.43,.065), 'white', .02, p)
        tail.rotation_euler.z = side * -.22
        for wy in (-.4, .1, .6):
            sphere(name + ' cabin window', (side*.445, wy, .17), (.025,.125,.105), 'navy', p, 12, 6)
        rod(name + ' main gear strut', (side*.62,.35,-.23), (side*.62,.35,-1.17), .045, 'silver', p)
        cyl(name + ' main wheel', (side*.62,.35,-1.18), .21, .12, 'navy', p, 'X')
    mesh(name + ' tail fin', [(-.05,1.15,.2),(-.05,1.89,.19),(-.05,1.78,1.48),
                             (.05,1.15,.2),(.05,1.89,.19),(.05,1.78,1.48)],
         [(0,1,2),(3,5,4),(0,3,4,1),(1,4,5,2),(2,5,3,0)], 'teal', p)
    rod(name + ' nose gear', (0,-1.40,-.27), (0,-1.40,-1.18), .042, 'silver', p)
    cyl(name + ' nose wheel', (0,-1.40,-1.18), .16, .11, 'navy', p, 'X')
    return p


def _box(root, loc, dims=(.62,.52,.44), color='kraft', tape=True):
    x,y,z=loc
    ob=cube('Neatly stored shipping carton', loc, dims, color, .025, root)
    if tape:
        cube('Carton sealing tape', (x,y,z+dims[2]/2+.006), (.07,dims[1]-.015,.013), 'pale', .002, root)
    cube('Blank inventory label', (x,y-dims[1]/2-.008,z), (.22,.014,.13), 'white', .006, root)
    return ob


def _rack(root, loc=(-4.9,4.9,0), color='teal', boxes=True, width=2.2, layers=3):
    rack=empty('Organised component shelving', loc, root)
    height=.22+.94*layers
    for x in (-width/2,width/2):
        for y in (-.36,.36):
            cube('Rack vertical', (x,y,height/2), (.075,.075,height), 'navy', .01, rack)
    for z in [.22+.94*i for i in range(layers+1)]:
        cube('Component shelf', (0,0,z), (width+.10,.83,.065), color, .012, rack)
    for layer,z in enumerate([.5+.94*i for i in range(layers)]):
        for i,x in enumerate((-width*.31,0,width*.31)):
            if boxes:
                _box(rack,(x,0,z),(.55,.53,.43),'kraft' if (layer+i)%2 else 'pale')
            else:
                cube('Open parts bin', (x,0,z), (.54,.52,.35), 'mint' if (i+layer)%2 else 'teal', .025, rack)
                cube('Bin front grip', (x,-.273,z+.09), (.19,.025,.055), 'navy', .008, rack)
    return rack


def _cart(root, loc=(-3.5,-.1,0), color='orange', tools=True):
    p=empty('Mobile maintenance tool cabinet',loc,root)
    cube('Tool cabinet', (0,0,.63), (1.10,.65,.93),color,.04,p)
    cube('Toolcart top tray', (0,0,1.12), (1.2,.75,.08),'navy',.025,p)
    for z in (.38,.60,.82):
        cube('Toolcart drawer', (0,-.341,z),(1.0,.032,.17),color,.012,p)
        cube('Toolcart handle', (0,-.373,z+.02),(.36,.038,.025),'silver',.004,p)
    for x in (-.4,.4):
        for y in (-.22,.22):
            cyl('Toolcart caster', (x,y,.13),.105,.07,'navy',p,'X',12)
    rod('Cart push bar', (.61,-.27,.97),(.61,.27,.97),.045,'silver',p)
    if tools:
        cube('Folded protective cloth',(-.25,.04,1.18),(.42,.38,.045),'mint',.02,p)
        rod('Cart screwdriver',(.10,-.15,1.185),(.41,-.15,1.185),.016,'silver',p)
        rod('Cart screwdriver grip',(.11,-.15,1.185),(.23,-.15,1.185),.035,'yellow',p)
    return p


def _plant(root, loc, scale=1):
    p=empty('Workplace greenery',loc,root);p.scale=(scale,scale,scale)
    cyl('Matte plant pot',(0,0,.19),.23,.38,'white',p,vertices=20)
    cyl('Pot rim',(0,0,.37),.25,.045,'teal',p,vertices=20)
    for i in range(5):
        angle=i*math.tau/5
        tip=(math.cos(angle)*.32,math.sin(angle)*.32,.82+(i%2)*.16)
        rod('Plant stem',(0,0,.36),tip,.015,'teal',p)
        leaf=sphere('Broad plant leaf',tip,(.115,.08,.32),'mint' if i%2 else 'teal',p,12,6)
        leaf.rotation_euler=(.24*math.cos(angle),.4*math.sin(angle),angle)
    return p


def _tools(root):
    # Neat tools at the left edge preserve room for the component and tablet.
    cube('Non-slip handtool mat',(-1.12,.12,1.22),(.47,.75,.018),'navy',.018,root)
    for i in range(2):
        x=-1.25+i*.23
        rod('Supported handtool shaft',(x,-.1,1.245),(x,.37,1.245),.018,'silver',root)
        rod('Handtool orange grip',(x,-.09,1.245),(x,.08,1.245),.037,'orange',root)
    cyl('Socket on tool mat',(-1.10,.39,1.25),.054,.055,'silver',root,vertices=12)


def _partition(root, y=-3.85, width=12):
    # Open panes keep the miniature hangar visible in Workbench rendering.
    for x in (-width/2,-width/3,-width/6,0,width/6,width/3,width/2):
        cube('Glass partition blue mullion',(x,y,1.8),(.055,.07,3.6),'navy',.009,root)
    for z in (.16,1.22,3.58):
        cube('Glass partition horizontal frame',(0,y,z),(width,.07,.05),'teal',.008,root)
    cube('Glass partition lower tint band',(0,y,.35),(width,.028,.26),'pale',.004,root)


def hangar(origin=(0,0,0)):
    root=empty('Maintenance hangar environment',origin)
    _floor(root)
    _industrial_back(root)
    plane=_plane(root,(.3,4.35,1.42))
    bench=_bench(root,'Maintenance bench')
    _tools(root)
    _cart(root,(-3.45,-.1,0))
    _cart(root,(4.1,-3.1,0),tools=False)
    # A second workstation for the avionics engineer, clear of the main story.
    cube('Avionics test worktop',(3.15,1.60,1.15),(2.15,.95,.12),'white',.04,root)
    cube('Avionics test cabinet',(3.15,1.63,.59),(2.0,.80,1.08),'teal',.035,root)
    for x in (2.70,3.60):
        cube('Avionics cabinet handle',(x,1.208,.68),(.30,.033,.035),'navy',.004,root)
    _rack(root,(-5.45,4.5,0),boxes=False,width=2.1)
    cube('Closed component crate',(-4.8,-4.2,.32),(1.20,.9,.64),'teal',.04,root)
    cube('Crate lid',(-4.8,-4.2,.67),(1.24,.94,.07),'mint',.02,root)
    area('Hangar broad window light',(2,-2,6.8),1300,7,(0,1,1),root)
    return {'root':root,'bench':bench,'plane':plane}


def office(origin=(0,0,0)):
    root=empty('Procurement office environment',origin)
    _floor(root,14,16,'pale')
    bench=_bench(root,'Procurement desk','navy',False)
    # A comfortable but deliberately compact chair behind the buyer.
    for x in (-.80,):
        cube('Navy office chair seat',(x,1.32,.52),(.62,.57,.13),'navy',.06,root)
        cube('Navy office chair back',(x,1.59,.96),(.61,.14,.76),'navy',.07,root)
        rod('Office chair pedestal',(x,1.32,.08),(x,1.32,.51),.065,'silver',root)
        for i in range(4):
            a=i*math.tau/4
            rod('Office chair foot',(x,1.32,.12),(x+.36*math.cos(a),1.32+.36*math.sin(a),.10),.028,'navy',root)
    _plant(root,(-2.05,-.50,0),1.15)
    _partition(root,-3.9,12)
    _plane(root,(1.1,-6.1,1.04),.60,'Jet beyond office glass')
    # Frames and columns make the open partition read as an office window wall.
    for x in (-6.2,6.2):
        cube('Office corner column',(x,-1.1,2.1),(.22,7,4.2),'white',.025,root)
    cube('Office back wall',(0,5.8,1.85),(12.6,.16,3.7),'white',.03,root)
    cube('Office teal wall panel',(-3.4,5.68,1.9),(3.5,.07,2.7),'teal',.02,root)
    _rack(root,(4.7,4.0,0),color='navy',boxes=True,width=1.55)
    for i in range(3):
        sheet=cube('Neatly stacked procurement document',(1.10,-.27,1.227+i*.015),(.46,.38,.012),'white' if i%2 else 'pale',.007,root)
        sheet.rotation_euler.z=.03*i
    cube('Document folder',(1.10,-.27,1.216),(.51,.41,.015),'mint',.008,root)
    cube('Office credenza',(-3.5,3.8,.58),(2.5,.75,1.16),'teal',.04,root)
    cube('Credenza countertop',(-3.5,3.8,1.19),(2.6,.81,.07),'white',.02,root)
    _plant(root,(-4.3,3.8,1.22),.65)
    area('Office soft daylight',(1,-3,5),1100,6,(0,0,1.3),root)
    return {'root':root,'bench':bench}


def dispatch(origin=(0,0,0)):
    root=empty('Dispatch packaging environment',origin)
    _floor(root,14,12)
    bench=_bench(root,'Protective packaging bench','teal')
    cube('Dispatch back wall',(0,5.9,2.35),(14,.16,4.7),'pale',.025,root)
    # Loading door, inset dark bay, raised roller frame, no signage or logos.
    cube('Loading bay recess',(2.0,5.79,1.92),(3.40,.07,3.84),'navy',.025,root)
    cube('Loading bay roller shutter',(2.0,5.71,2.47),(3.15,.07,2.37),'silver',.015,root)
    for z in (1.48,1.83,2.18,2.53,2.88,3.23,3.58):
        cube('Roller shutter horizontal slat',(2.0,5.655,z),(3.10,.015,.035),'pale',.004,root)
    for x in (.20,3.8):
        cube('Loading bay safety bollard',(x,5.08,.54),(.16,.16,1.08),'yellow',.025,root)
    _rack(root,(-4.55,4.1,0),boxes=True,width=2.35)
    _rack(root,(5.0,3.65,0),boxes=False,width=2.0)
    # Ready-to-ship cartons on a pale wooden pallet, tucked out of actor paths.
    for x in (-.46,0,.46):
        cube('Pallet plank',(3.9+x,2.15,.12),(.27,1.16,.07),'kraft',.015,root)
    for x in (3.62,4.18):
        cube('Pallet runner',(x,2.15,.05),(.15,1.2,.09),'kraft',.01,root)
    _box(root,(3.6,2.15,.51),(.63,.67,.68))
    _box(root,(4.3,2.15,.45),(.60,.65,.56))
    _box(root,(3.60,2.15,1.03),(.60,.63,.33),'pale')
    _cart(root,(-3.1,-.7,0),tools=False)
    cube('Roll of packing paper',(-1.05,.18,1.28),(.50,.20,.14),'kraft',.06,root)
    cube('Supported packing tape dispenser',(-1.14,-.22,1.27),(.23,.30,.12),'orange',.025,root)
    cyl('Packing tape roll',(-1.14,-.18,1.34),.095,.10,'pale',root,'X')
    area('Dispatch skylight',(0,-1,5.8),1100,6,(0,1,1.2),root)
    return {'root':root,'bench':bench}


def receiving(origin=(0,0,0)):
    root=empty('Receiving inspection environment',origin)
    _floor(root,15,15)
    bench=_bench(root,'Receiving inspection counter','mint')
    _partition(root,-4.1,13)
    _plane(root,(.2,-6.1,1.02),.58,'Aircraft beyond receiving windows')
    cube('Receiving rear wall',(0,6.9,2.30),(15,.15,4.6),'pale',.03,root)
    cube('Receiving blue clerestory',(0,6.79,3.28),(14.6,.045,1.7),'sky',.01,root)
    for x in (-6.5,-3.2,0,3.2,6.5):
        cube('Receiving structural mullion',(x,6.72,3.29),(.10,.075,1.85),'blue',.008,root)
    _rack(root,(-4.75,3.8,0),boxes=True,width=2.10,layers=2)
    _rack(root,(4.85,4.5,0),boxes=False,width=2.0,layers=2)
    _plant(root,(-3.0,-.55,0),1.15)
    # The handtruck and its carton show inbound movement without clutter.
    truck=empty('Incoming parcel handtruck',(4.0,-2.4,0),root)
    for x in (-.28,.28):
        rod('Handtruck upright',(x,0,.15),(x,.18,1.33),.04,'orange',truck)
        cyl('Handtruck wheel',(x,.07,.18),.16,.11,'navy',truck,'X')
    rod('Handtruck top grip',(-.28,.18,1.33),(.28,.18,1.33),.045,'navy',truck)
    cube('Handtruck toe plate',(0,-.22,.14),(.71,.65,.06),'silver',.015,truck)
    _box(truck,(0,-.20,.48),(.65,.53,.60))
    cube('Counter document tray',(-1.10,-.32,1.265),(.49,.37,.11),'navy',.018,root)
    cube('Receipt document',(-1.10,-.32,1.33),(.40,.29,.018),'white',.007,root)
    cube('Inbound staging pedestal',(3.4,2.60,.48),(1.45,.86,.96),'teal',.025,root)
    cube('Staging tabletop',(3.4,2.60,1.0),(1.53,.94,.08),'white',.02,root)
    _box(root,(3.4,2.60,1.26),(.61,.56,.43),'kraft')
    area('Receiving soft window light',(-1,-3,6),1200,7,(0,0,1.4),root)
    return {'root':root,'bench':bench}
