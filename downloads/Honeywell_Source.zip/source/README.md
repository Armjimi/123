# Honeywell GoDirect Trade — animated opening

Original illustrative 3D animation, based on the user's 30-second brief. All characters, facilities, interface pictures and audio are created for this film. Company names are plain text, with no invented logos.

The animation follows a consistent silver cylindrical component with a blue identification band and rectangular plate. Only digital records enter the animated permissioned network. Network checks concern submitted records; they do not independently prove that maintenance took place or certify airworthiness.

## Rebuild

Blender 4.3.2, FFmpeg, Python 3, NumPy and SciPy are used. No external assets or credentials are needed.

```sh
cd /workspace/honeywell-opening
python3 source/audio.py
XDG_CACHE_HOME=/workspace/honeywell-opening/cache blender -b -t 4 --python source/build_film.py -- --previews
XDG_CACHE_HOME=/workspace/honeywell-opening/cache blender -b delivery/Honeywell_Opening.blend -t 4 --python source/render_film.py -- --step 1
python3 source/compose.py --fps 24 --no-interpolation
```

The Blender timeline contains all 720 frames at 24 fps. The delivered film uses native 1920×1080 renders for every frame. FXAA cleans the edges, and final titles are composed at full resolution. For a faster optional draft, render with `--step 2` and assemble with `--fps 12`; this interpolates to 24 fps. Use a clean render directory when changing cadence.

## Shot timing

| Time | Action |
|---|---|
| 0–5s | Hangar inspection and identification plate |
| 5–10s | Four pictographic aircraft-part history categories |
| 10–16s | Authorized record submission, three network computers, appended history block |
| 16–21s | Marketplace selection and history review |
| 21–26s | Related repair document, order confirmation, protective packing |
| 26–30s | Package arrival, identification matching, closing caption |

The soundtrack is an original instrumental synthesis with synchronized effects and no human voices.
