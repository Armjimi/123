"""Physical displays and large, picture-only record graphics for the film."""
import math
import bpy
from common import empty, cube, cyl, rod, mesh


def _poly(name, points, material='blue', parent=None, z=.02, depth=.018):
    n = len(points)
    verts = [(x, y, z) for x, y in points] + [(x, y, z+depth) for x, y in points]
    faces = [tuple(reversed(range(n))), tuple(range(n, 2*n))]
    faces += [(i, (i+1)%n, (i+1)%n+n, i+n) for i in range(n)]
    return mesh(name, verts, faces, material, parent)


def _bar(name, a, b, width=.065, material='blue', parent=None, z=.045):
    x1,y1 = a; x2,y2 = b
    ob = cube(name, ((x1+x2)/2, (y1+y2)/2, z),
              (math.hypot(x2-x1,y2-y1), width, .018), material,
              bevel=min(.015,width/4), parent=parent)
    ob.rotation_euler.z = math.atan2(y2-y1,x2-x1)
    return ob


def _arrow(name, x=-.27, y=0, length=.54, parent=None, material='blue'):
    p=[(x,y-.035),(x+length-.14,y-.035),(x+length-.14,y-.13),
       (x+length,y),(x+length-.14,y+.13),(x+length-.14,y+.035),(x,y+.035)]
    return _poly(name,p,material,parent,z=.065)


def _identity_plate(name, loc, width, height, parent):
    """The same white, blue-stripe, eleven-bar identity as the real part/box."""
    r=empty(name,loc,parent)
    cube(name+' white serialized label',(0,0,0),(width,height,.03),'white',.006,r)
    cube(name+' matching blue identity stripe',(-width*.119/.29,0,.020),
         (width*.029/.29,height*.078/.095,.01),'blue',.002,r)
    widths=[.009,.004,.013,.005,.008,.013,.004,.006,.011,.004,.007]
    x=-.090
    for i,w in enumerate(widths):
        cube(name+' barcode '+str(i),(x*width/.29,0,.021),
             (w*width/.29,height*.059/.095,.009),'ink',.001,r)
        x+=w+.006
    return r


def device(name, loc=(0,0,0), parent=None, width=2.2, height=1.35, kind='tablet'):
    root=empty(name,loc,parent)
    root.rotation_euler.x=math.pi/2
    cube(name+' manufactured casing',(0,0,0),(width,height,.08),'navy',.055,root)
    cube(name+' glass display',(0,0,.048),(width-.12,height-.12,.019),'white',.03,root)
    screen=empty(name+' screen graphics',(0,0,.07),root)
    # Everything is attached to the device, including its ordinary desk stand.
    if kind=='monitor':
        cube(name+' stand stem',(0,-height/2-.16,-.035),(.17,.32,.13),'silver',.025,root)
        cube(name+' stand foot',(0,-height/2-.33,0),(.68,.065,.45),'navy',.025,root)
    else:
        cube(name+' tablet support',(0,-height/2-.055,-.02),(.72,.11,.24),'navy',.025,root)
    cyl(name+' power dot',(width/2-.055,-height/2+.10,.061),.018,.012,'mint',root,vertices=12)
    return {'root':root,'screen':screen}


def icon(name, kind, loc=(0,0,0), parent=None, scale=1):
    r=empty(name,loc,parent);r.scale=(scale,scale,scale)
    if kind=='component':
        cyl(name+' silver component',(-.02,.025,.045),.18,.61,'silver',r,axis='X')
        cyl(name+' blue identity band',(-.12,.025,.046),.19,.11,'blue',r,axis='X')
        cyl(name+' collar',(-.33,.025,.045),.20,.065,'pale',r,axis='X')
        _identity_plate(name+' rectangular ID plate',(-.035,-.065,.22),.33,.135,r)
    elif kind=='usage':
        _poly(name+' aircraft',[(-.39,.12),(-.11,.18),(-.08,.34),(.015,.36),(.065,.18),
             (.40,.07),(.40,.005),(.05,.06),(.00,-.20),(-.08,-.20),(-.13,.06),(-.39,.045)],'blue',r)
        cyl(name+' clock face',(.22,-.22,.055),.18,.035,'navy',r,vertices=24)
        cyl(name+' clock center',(.22,-.22,.076),.145,.01,'white',r,vertices=24)
        _bar(name+' clock minute',(.22,-.22),(.22,-.11),.025,'navy',r,.089)
        _bar(name+' clock hour',(.22,-.22),(.30,-.24),.025,'navy',r,.089)
    elif kind=='repair':
        icon(name+' part','component',(.16,-.15,.014),r,.67)
        wrench=[(-.34,-.23),(-.26,-.30),(.16,.14),(.25,.12),(.37,.19),(.40,.31),
                (.29,.27),(.21,.34),(.24,.44),(.13,.39),(.075,.27),(.105,.18)]
        _poly(name+' wrench',wrench,'blue',r,z=.12,depth=.023)
    elif kind=='ownership':
        for side,x in [('before',-.25),('after',.25)]:
            cube(name+' '+side+' building',(x,.10,.035),(.27,.40,.035),'blue' if x<0 else 'teal',.018,r)
            for xx in (-.064,.064):
                for yy in (.055,.19):
                    cube(name+' window',(x+xx,yy,.06),(.06,.07,.012),'white',.004,r)
            cube(name+' doorway',(x,-.065,.07),(.065,.105,.016),'navy',.004,r)
        _arrow(name+' ownership transfer',-.25,-.24,.50,r,'orange')
    elif kind=='documents':
        _poly(name+' folder tab',[(-.38,-.24),(-.38,.23),(-.12,.23),(-.035,.13),(.35,.13),(.35,-.24)],'yellow',r)
        cube(name+' document',(.07,.01,.07),(.40,.42,.02),'white',.02,r)
        for i in range(3):
            cube(name+' report rule',(.07,.12-i*.105,.087),(.25,.034,.009),'blue',.005,r)
        _poly(name+' open folder front',[(-.42,-.28),(-.34,.01),(.42,.01),(.34,-.28)],'orange',r,z=.1)
    elif kind=='check':
        cyl(name+' confirmed disc',(0,0,.03),.37,.035,'teal',r,vertices=32)
        _bar(name+' tick short',(-.19,-.015),(-.055,-.15),.095,'white',r,.064)
        _bar(name+' tick long',(-.055,-.15),(.22,.16),.095,'white',r,.064)
    elif kind=='badge':
        cube(name+' staff card',(0,0,.03),(.57,.76,.045),'white',.035,r)
        cube(name+' blue card header',(0,.25,.057),(.46,.12,.012),'blue',.01,r)
        cyl(name+' portrait head',(-.10,.035,.072),.083,.013,'teal',r,vertices=16)
        _poly(name+' portrait shoulders',[(-.235,-.20),(-.215,-.095),(-.10,-.055),(.015,-.095),(.035,-.20)],'teal',r,.077)
        cube(name+' badge permission',(.155,-.04,.070),(.075,.075,.02),'blue',.01,r)
    elif kind=='computer':
        cube(name+' monitor',(0,.07,.025),(.76,.49,.038),'navy',.025,r)
        cube(name+' screen',(0,.075,.049),(.66,.39,.013),'pale',.014,r)
        cube(name+' stem',(0,-.245,.025),(.10,.15,.03),'navy',.01,r)
        cube(name+' base',(0,-.33,.025),(.38,.055,.03),'navy',.01,r)
    elif kind=='record':
        _poly(name+' document silhouette',[(-.25,-.35),(-.25,.35),(.12,.35),(.27,.19),(.27,-.35)],'white',r)
        _poly(name+' folded corner',[(.105,.34),(.105,.18),(.265,.18)],'sky',r,z=.045)
        cube(name+' record header',(-.055,.165,.057),(.28,.065,.012),'blue',.006,r)
        for i in range(3):
            cube(name+' record row '+str(i),(.01,.02-i*.11,.057),(.34,.045,.012),'teal' if i==2 else 'sky',.005,r)
    else:
        raise ValueError('Unknown pictogram kind: '+kind)
    return r


def _component_header(name,parent,width,height):
    r=icon(name+' matching component','component',(-width*.30,height*.31,.055),parent,scale=width*.28)
    _identity_plate(name+' identity plate',(width*.16,height*.31,.055),width*.40,height*.20,parent)
    return r


def history(name, parent, width=2, height=1.1, timeline=False):
    root=empty(name,parent=parent)
    comp=_component_header(name,root,width,height)
    kinds=['usage','repair','ownership','documents']; tiles=[]
    if timeline:
        y=-height*.20
        _bar(name+' connected history',(-width*.39,y),(width*.39,y),.023,'sky',root,z=.034)
        centers=[(-width*.375+i*width*.25,y) for i in range(4)]
        tw,th=width*.205,height*.49
    else:
        centers=[(-width*.25,-height*.055),(width*.25,-height*.055),
                 (-width*.25,-height*.345),(width*.25,-height*.345)]
        tw,th=width*.43,height*.255
    for i,(kind,(x,y)) in enumerate(zip(kinds,centers)):
        tile=empty(name+' '+kind+' tile',(x,y,.055),root)
        cube(name+' '+kind+' tile background',(0,0,0),(tw,th,.018),'pale',.02,tile)
        icon(name+' '+kind+' pictogram',kind,(0,0,.022),tile,scale=min(tw*.82,th*1.05))
        tiles.append(tile)
    return {'root':root,'tiles':tiles,'component':comp}


def blockchain(name,parent,width=2,height=1.1):
    root=empty(name,parent=parent)
    computers=[];lights=[];replica_new=[];blocks=[]
    cw=width*.25; cy=height*.21
    # Ordinary authorized computers, joined by simple diagram cables.
    _bar(name+' network cable',(-width*.33,cy),(width*.33,cy),.026,'sky',root,z=.028)
    for i in range(3):
        x=(i-1)*width*.33
        comp=icon(name+' authorized computer '+str(i),'computer',(x,cy,.04),root,cw)
        computers.append(comp)
        light=cyl(name+' validation lamp '+str(i),(x+cw*.29,cy+cw*.31,.087),cw*.047,.018,'mint',root,vertices=12)
        lights.append(light)
        # Every participant retains the same sequence, including the arriving record.
        for j in range(4):
            rr=empty(name+' replicated block '+str(i)+' '+str(j),(-.23+j*.15,.035,.073),comp)
            cube(name+' local replica cell',(0,0,0),(.105,.115,.015),'blue' if j<3 else 'teal',.009,rr)
            if j==3: replica_new.append(rr)
    by=-height*.31; bw=width*.16
    _bar(name+' chronological chain',(-width*.38,by),(width*.38,by),.035,'blue',root,z=.032)
    for j in range(4):
        block=empty(name+' retained chain block '+str(j),(-width*.345+j*width*.23,by,.055),root)
        cube(name+' chain record block',(0,0,0),(bw,height*.26,.022),'blue' if j<3 else 'teal',.025,block)
        icon(name+' linked record '+str(j),'record',(0,0,.028),block,scale=min(bw*.9,height*.29))
        blocks.append(block)
    record=icon(name+' submitted digital record','record',(-width*.40,-height*.035,.12),root,width*.17)
    return {'root':root,'computers':computers,'lights':lights,'blocks':blocks,
            'replica_new':replica_new,'record':record}


def repair_document(name,parent,width=2,height=1.1):
    root=empty(name,parent=parent)
    icon(name+' selected repair','repair',(-width*.31,.035,.055),root,scale=min(width*.50,height*.79))
    _arrow(name+' linked report',-width*.105,0,width*.20,root,'sky')
    # A full-size, readily visible report has an attached file icon and approval mark.
    report=icon(name+' original repair record','record',(width*.22,.015,.06),root,scale=height*1.01)
    icon(name+' linked document file','documents',(width*.39,-height*.22,.12),root,scale=height*.46)
    icon(name+' document confirmed','check',(width*.36,height*.31,.14),root,scale=height*.26)
    return root
