import bpy, math
from mathutils import Vector

PALETTE = {
 'navy': (0.025,0.075,0.15,1), 'blue': (0.025,0.32,0.66,1),
 'sky': (0.32,0.65,0.84,1), 'teal': (0.025,0.48,0.49,1),
 'mint': (0.40,0.76,0.62,1), 'yellow': (0.96,0.67,0.12,1),
 'orange': (0.96,0.30,0.08,1), 'red': (0.72,0.035,0.05,1),
 'white': (0.93,0.96,0.95,1), 'silver': (0.60,0.69,0.72,1),
 'ink': (0.012,0.029,0.048,1), 'pale': (0.71,0.84,0.88,1),
 'floor': (0.29,0.40,0.45,1), 'kraft': (0.67,0.43,0.22,1),
}

def mat(name, color=None, metallic=0, emission=0):
    if bpy.data.materials.get(name): return bpy.data.materials[name]
    m=bpy.data.materials.new(name); m.diffuse_color=color or PALETTE.get(name,PALETTE['white'])
    m.use_nodes=True; p=m.node_tree.nodes.get('Principled BSDF')
    p.inputs['Base Color'].default_value=m.diffuse_color
    p.inputs['Roughness'].default_value=.76; p.inputs['Metallic'].default_value=metallic
    if emission:
        p.inputs['Emission Color'].default_value=m.diffuse_color
        p.inputs['Emission Strength'].default_value=emission
    return m

def parent_obj(obj,parent):
    if parent: obj.parent=parent
    return obj

def empty(name,loc=(0,0,0),parent=None):
    ob=bpy.data.objects.new(name,None); bpy.context.collection.objects.link(ob)
    ob.location=loc; parent_obj(ob,parent); return ob

def assign(ob,material):
    ob.data.materials.append(mat(material) if isinstance(material,str) else material); return ob

def cube(name,loc,dims,material='white',bevel=.03,parent=None):
    bpy.ops.mesh.primitive_cube_add(size=1,location=(0,0,0)); ob=bpy.context.object; ob.name=name
    ob.dimensions=dims; bpy.ops.object.transform_apply(location=False,rotation=False,scale=True)
    ob.location=loc; assign(ob,material); parent_obj(ob,parent)
    if bevel:
        mod=ob.modifiers.new('Soft manufactured edges','BEVEL'); mod.width=bevel; mod.segments=2
        mod=ob.modifiers.new('Weighted normals','WEIGHTED_NORMAL')
    return ob

def sphere(name,loc,scale,material='white',parent=None,segments=16,rings=8,smooth=True):
    bpy.ops.mesh.primitive_uv_sphere_add(segments=segments,ring_count=rings,radius=1)
    ob=bpy.context.object; ob.name=name; ob.location=loc; ob.scale=scale
    assign(ob,material); parent_obj(ob,parent)
    if smooth:
        for p in ob.data.polygons: p.use_smooth=True
    return ob

def cyl(name,loc,radius,depth,material='silver',parent=None,axis='Z',vertices=16):
    bpy.ops.mesh.primitive_cylinder_add(vertices=vertices,radius=radius,depth=depth)
    ob=bpy.context.object; ob.name=name; ob.location=loc
    if axis=='Y': ob.rotation_euler.x=math.pi/2
    if axis=='X': ob.rotation_euler.y=math.pi/2
    assign(ob,material); parent_obj(ob,parent)
    bevel=ob.modifiers.new('Rim finish','BEVEL'); bevel.width=.012; bevel.segments=1
    ob.modifiers.new('Weighted normals','WEIGHTED_NORMAL'); return ob

def rod(name,a,b,radius,material='silver',parent=None):
    a,b=Vector(a),Vector(b); ob=cyl(name,(a+b)/2,radius,(b-a).length,material,parent)
    ob.rotation_euler=(b-a).to_track_quat('Z','Y').to_euler(); return ob

def mesh(name,verts,faces,material='white',parent=None):
    me=bpy.data.meshes.new(name); me.from_pydata(verts,[],faces); me.update()
    ob=bpy.data.objects.new(name,me); bpy.context.collection.objects.link(ob); assign(ob,material)
    parent_obj(ob,parent); return ob

def text(name,body,loc,size=.2,material='navy',parent=None,align='CENTER'):
    cu=bpy.data.curves.new(name,'FONT'); cu.body=body; cu.size=size; cu.align_x=align
    cu.align_y='CENTER'; cu.extrude=.0003; cu.space_character=1.03
    fontpath='/usr/share/fonts/truetype/open-sans/OpenSans-Semibold.ttf'
    try: cu.font=bpy.data.fonts.load(fontpath,check_existing=True)
    except: pass
    ob=bpy.data.objects.new(name,cu); bpy.context.collection.objects.link(ob)
    ob.location=loc; assign(ob,material); parent_obj(ob,parent); return ob

def key(ob,prop,frame,value):
    setattr(ob,prop,value); ob.keyframe_insert(data_path=prop,frame=frame)

def appear(ob,start,end=721):
    for frame,value in [(1,True),(max(1,start-1),True),(start,False),(end,True)]:
        ob.hide_render=value; ob.keyframe_insert('hide_render',frame=frame)
    for ch in ob.children: appear(ch,start,end)

def reveal(ob,frame):
    for f,s in [(1,.001),(frame-1,.001),(frame+6,1.)]: key(ob,'scale',f,(s,s,s))

def camera_pose(cam,frame,loc,target,lens=48):
    cam.location=loc; cam.rotation_euler=(Vector(target)-cam.location).to_track_quat('-Z','Y').to_euler()
    cam.keyframe_insert('location',frame=frame); cam.keyframe_insert('rotation_euler',frame=frame)
    cam.data.lens=lens; cam.data.keyframe_insert('lens',frame=frame)

def area(name,loc,energy,size,target,parent=None,color=(1,1,1)):
    d=bpy.data.lights.new(name,'AREA'); d.energy=energy; d.shape='DISK'; d.size=size; d.color=color
    ob=bpy.data.objects.new(name,d); bpy.context.collection.objects.link(ob); ob.location=loc
    ob.rotation_euler=(Vector(target)-Vector(loc)).to_track_quat('-Z','Y').to_euler()
    parent_obj(ob,parent); return ob
