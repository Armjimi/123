"""Build an original, fully animated six-scene aviation miniature in Blender."""
import bpy, sys, os, math, argparse
from pathlib import Path
from mathutils import Vector, Quaternion
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
from common import *
from characters import character, component, package
from environments import hangar, office, dispatch, receiving
from screens import device, icon, history, blockchain, repair_document

BASE=HERE.parent
FPS=24
def frame(t): return round(t*FPS)+1

def rotation(ob,keys):
    for t,r in keys: key(ob,'rotation_euler',frame(t),r)

def motion(ob,keys):
    for t,p in keys: key(ob,'location',frame(t),p)

def nod(person,t):
    h=person['head']; r=h.rotation_euler.copy()
    for dt,v in [(0,0),(.18,.18),(.40,0),(.6,.08),(.8,0)]:
        q=r.copy();q.x+=v;key(h,'rotation_euler',frame(t+dt),q)

def reach(person,side,times,points):
    arm=person[side+'_arm']
    root=person['root']
    for t,p in zip(times,points):
        bpy.context.scene.frame_set(frame(t)); bpy.context.view_layer.update()
        pivot=arm.matrix_world.translation
        aim=Vector(p)-pivot
        upper=.315;lower=.417;dist=max(.105,min(.731,aim.length))
        alpha=math.acos(max(-1,min(1,(upper*upper+dist*dist-lower*lower)/(2*upper*dist))))
        theta=math.pi-math.acos(max(-1,min(1,(upper*upper+lower*lower-dist*dist)/(2*upper*lower))))
        world=aim.to_track_quat('-Z','Y') @ Quaternion((1,0,0),alpha)
        local=root.matrix_world.inverted().to_3x3() @ world.to_matrix()
        key(arm,'rotation_euler',frame(t),local.to_euler())
        key(person[side+'_forearm'],'rotation_euler',frame(t),(-theta,0,0))

def activity(person,start,end):
    for t in range(start,end,2):
        nod(person,t)

def sidestep(person,start,end,x0,x1):
    """Small alternating steps keep a supported foot and articulated legs."""
    root=person['root']; feet={'left':x0-.145,'right':x0+.145}
    height={'left':0.,'right':0.}
    for step in range(4):
        side='left' if step%2==0 else 'right'
        old=feet[side];new=old+(x1-x0)/2
        for phase in (0,.5,1):
            t=start+(end-start)*(step+phase)/4
            progress=(step+phase)/4
            rx=x0+(x1-x0)*progress
            key(root,'location',frame(t),(rx,.84,0))
            if phase==0:fx=old;fz=0
            elif phase==.5:fx=(old+new)/2;fz=.09
            else:fx=new;fz=0
            for which in ('left','right'):
                px=fx if which==side else feet[which]
                pz=fz if which==side else 0
                sign=-1 if which=='left' else 1
                for suffix,z in [(' shoe',.105),(' outsole',.028)]:
                    ob=bpy.data.objects[root.name+' '+which+suffix]
                    key(ob,'location',frame(t),(px-rx,-.075,z+pz))
                leg=bpy.data.objects[root.name+' '+which+' trouser']
                a=Vector((sign*.145,.018,.755));b=Vector((px-rx,.018,.16+pz))
                key(leg,'location',frame(t),(a+b)/2)
                key(leg,'rotation_euler',frame(t),(a-b).to_track_quat('Z','Y').to_euler())
                key(leg,'scale',frame(t),(1,1,(a-b).length/.61))
        feet[side]=new

def screen_facing_staff(d):
    d['root'].rotation_euler=(math.pi/2,0,math.pi)

def pose(cam,t,loc,target,lens=48): camera_pose(cam,frame(t),loc,target,lens)

def block_transition_animation(ui):
    # Submitted digital record propagates to three authorized computers.
    for i,computer in enumerate(ui['computers']):
        ob=icon('Submitted repair record '+str(i),'record',(-.45,.025,.14),ui['root'],scale=.17)
        p=computer.location.copy();p.z=.15
        motion(ob,[(11.15+i*.35,(-.45,.025,.15)),(12.15+i*.35,(p.x,p.y,.15))])
        appear(ob,frame(11.15+i*.35),frame(12.2+i*.35))
    for i,light in enumerate(ui['lights']):
        light.data.materials.clear();light.data.materials.append(mat('mint'))
        appear(light,frame(12.2+i*.35),frame(16))
    new=ui['blocks'][-1]
    reveal(new,frame(14.05))
    for n in ui.get('replica_new',[]): reveal(n,frame(14.75))
    if ui.get('record'): appear(ui['record'],frame(10.7),frame(11.45))

def build():
    bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
    s=bpy.context.scene;s.frame_start=1;s.frame_end=720;s.render.fps=FPS
    s.render.resolution_x=1920;s.render.resolution_y=1080;s.render.resolution_percentage=100
    s.render.image_settings.file_format='PNG';s.render.image_settings.color_mode='RGB'
    s.render.engine='BLENDER_WORKBENCH'
    s.display.render_aa='FXAA';sh=s.display.shading
    sh.light='STUDIO';sh.studiolight_rotate_z=.4;sh.color_type='MATERIAL'
    sh.show_shadows=True;sh.shadow_intensity=.35
    sh.show_cavity=True;sh.cavity_type='BOTH';sh.curvature_ridge_factor=1.3
    sh.curvature_valley_factor=1.1;sh.cavity_ridge_factor=1.0;sh.cavity_valley_factor=1.05
    sh.show_specular_highlight=False;sh.background_type='WORLD'
    s.world.color=(.66,.78,.85)
    s.view_settings.view_transform='Standard';s.view_settings.look='Medium High Contrast'
    s.view_settings.exposure=0;s.view_settings.gamma=1
    bpy.ops.object.camera_add();cam=bpy.context.object;cam.name='Story camera';s.camera=cam
    cam.data.lens=48;cam.data.clip_end=160;cam.data.dof.use_dof=False

    # One repeated component design; no physical hardware ever enters a network.
    h=hangar((0,0,0))
    tech=character('Alex | aircraft technician',(-.4,.84,0),'technician')
    comp=component('Tracked component | maintenance',(-.40,.18,1.49))
    cube('Dark supported component cradle',(-.4,.18,1.27),(.84,.42,.09),'navy')
    engineer=character('Maya | avionics engineer',(3.65,2.34,0),'engineer',yaw=-.70)
    ed=device('Avionics test display',(2.9,1.66,1.99),width=1.35,height=.85,kind='monitor')
    screen_facing_staff(ed)
    for x in range(3):
        cube('Test signal bar',(-.40+x*.30,-.05,.11),(.12,.27+x*.11,.015),'mint',parent=ed['screen'])
    icon('Test circuitry','component',(.0,.27,.12),ed['screen'],scale=.38)
    activity(engineer,0,30)
    helper=character('Background maintenance colleague',(-4.5,3.7,0),'technician',yaw=-.25)
    activity(helper,1,30)
    # Small supported tablet with four pictographic records.
    tab=device('Component history tablet',(.85,.20,1.78),width=1.35,height=.90)
    screen_facing_staff(tab)
    hist=history('Four retained history categories',tab['screen'],width=1.23,height=.74)
    for i,tile in enumerate(hist['tiles']): reveal(tile,frame(5.85+i*.90))
    appear(hist['root'],1,frame(10.6))
    net=blockchain('Permissioned record network',tab['screen'],width=1.23,height=.74)
    appear(net['root'],frame(10.6),frame(16))
    block_transition_animation(net)
    # Scan an ordinary staff badge against the device reader before submitting.
    scanner=cube('Staff badge reader',(.00,.40,1.49),(.18,.15,.28),'navy')
    cube('Reader confirmation light',(.00,.482,1.57),(.08,.02,.045),'mint')
    badge=cube('Authorized staff card',(0,0,.02),(.20,.045,.29),'white',parent=tech['right_hand'])
    badge_orientation=empty('Upright staff badge orientation')
    constraint=badge.constraints.new('COPY_ROTATION');constraint.target=badge_orientation
    constraint.owner_space='WORLD';constraint.target_space='WORLD'
    badge_icon=icon('Badge pictogram','badge',(0,-.028,0),badge,scale=.24)
    badge_icon.rotation_euler.x=math.pi/2
    appear(badge,frame(10.1),frame(10.7))
    nod(tech,1.45);nod(tech,3.25)
    reach(tech,'right',[0,1.5,3.5,4.9,5.55,5.85,6.1,9.5,10.35,11.1,11.4,15.8],[(-.16,.20,1.49),(-.14,.20,1.53),(-.11,.20,1.49),(-.15,.20,1.49),(.25,.31,1.53),(.25,.29,1.53),(.25,.35,1.50),(-.12,.25,1.5),(.00,.50,1.49),(.25,.35,1.53),(.25,.29,1.53),(-.16,.2,1.49)])
    reach(tech,'left',[0,3,5,16],[(-.64,.20,1.49),(-.64,.20,1.51),(-.64,.20,1.49),(-.64,.20,1.49)])
    pose(cam,0,(-4.4,-7.2,4.0),(.45,1.15,1.50),36)
    pose(cam,4.96,(-3.15,-5.7,3.25),(.25,.7,1.55),43)
    pose(cam,5,(2.8,3.5,3.4),(.35,.12,1.65),40)
    pose(cam,9.96,(2.1,3.0,2.85),(.55,.20,1.72),43)
    pose(cam,10,(2.1,3.0,2.85),(.55,.20,1.72),43)
    pose(cam,11.25,(.89,2.45,1.96),(.85,.20,1.78),49)
    pose(cam,15.96,(.89,2.25,1.88),(.85,.20,1.78),49)

    # Procurement: same screen colors and component make a match cut.
    o=office((24,0,0))
    buyer=character('Sam | procurement buyer',(22.70,.90,0),'buyer')
    mon=device('Procurement workstation',(24.35,-.06,2.30),width=2.55,height=1.50,kind='monitor')
    screen_facing_staff(mon)
    text('Marketplace heading','Honeywell GoDirect Trade',(0,.61,.13),size=.15,parent=mon['screen'])
    listings=empty('Marketplace product selection',parent=mon['screen'])
    for i in range(3):
        card=empty('Product option '+str(i),(-.74+i*.75,-.04,.13),listings)
        cube('Product tile',(0,0,0),(.67,.80,.02),'white',parent=card)
        icon('Available component '+str(i),'component',(0,.05,.04),card,scale=.63 if i==1 else .40)
        cube('Select product control',(0,-.26,.06),(.42,.065,.015),'blue' if i==1 else 'pale',parent=card)
    appear(listings,frame(16),frame(17.35))
    mh=history('Buyer component history timeline',mon['screen'],width=2.27,height=1.08,timeline=True)
    appear(mh['root'],frame(17.35),frame(21.25))
    for ob in mh['tiles']: reveal(ob,frame(17.35))
    doc=repair_document('Linked repair record and document',mon['screen'],width=2.25,height=1.06)
    appear(doc,frame(21.25),frame(22.55))
    conf=icon('Single order confirmation','check',(0,-.02,.16),mon['screen'],scale=.65)
    appear(conf,frame(22.55),frame(23))
    # Supported keyboard, mouse, and a small hand movement.
    cube('Keyboard',(24.3,.58,1.25),(1.25,.34,.04),'navy')
    for r in range(3):
        for c in range(10): cube('Keyboard key',(23.79+c*.11,.47+r*.09,1.28),(.08,.065,.018),'pale',bevel=.004)
    sphere('Mouse',(23.46,.57,1.28),(.11,.17,.04),'white')
    reach(buyer,'right',[16,17.1,17.35,19,21.2,22.45,22.75],[(23.46,.57,1.36),(23.46,.57,1.33),(23.46,.57,1.35),(23.46,.57,1.36),(23.46,.57,1.33),(23.46,.57,1.32),(23.46,.57,1.37)])
    nod(buyer,19.2);nod(buyer,22.55)
    pose(cam,16,(24.28,3.20,2.45),(24.35,-.06,2.30),49)
    pose(cam,17.05,(25.9,4.2,3.20),(24.3,0,2.14),43)
    pose(cam,20.96,(25.6,3.8,3.02),(24.3,0,2.20),44)
    pose(cam,21,(25.6,3.8,3.02),(24.3,0,2.20),44)
    pose(cam,22.96,(25.3,3.55,2.9),(24.3,-.06,2.22),44)

    # Dispatch: lift clear of the bench, lower into open protective packaging.
    d=dispatch((48,0,0))
    for ob in d['root'].children:
        if ob.name.startswith('Protective packaging bench'):
            if 'square leg' in ob.name: ob.dimensions.z-=.18;ob.location.z-=.09
            elif 'low shelf' not in ob.name: ob.location.z-=.18
        elif ob.name.startswith(('Roll of packing paper','Supported packing tape dispenser','Packing tape roll')): ob.location.z-=.18
    packer=character('Alex | dispatch technician',(47.30,.84,0),'technician')
    motion(packer['root'],[(23,(47.30,.84,0)),(23.9,(47.30,.84,0)),(24.8,(48.17,.84,0)),(25.96,(48.17,.84,0))])
    sidestep(packer,23.9,24.8,47.3,48.17)
    boxed=package('Identified protective shipping package',(48.17,.20,1.04))
    part=component('Tracked component | packing',(47.3,.20,1.205))
    motion(part,[(23,(47.3,.20,1.205)),(23.48,(47.3,.20,1.205)),(23.90,(47.3,.20,1.725)),(24.80,(48.17,.20,1.725)),(25.10,(48.17,.20,1.345)),(25.96,(48.17,.20,1.345))])
    reach(packer,'right',[23,23.48,23.9,24.8,25.1,25.6],[(47.54,.20,1.205),(47.54,.20,1.205),(47.54,.20,1.725),(48.41,.20,1.725),(48.41,.20,1.345),(48.41,.20,1.60)])
    reach(packer,'left',[23,23.48,23.9,24.8,25.1,25.6],[(47.06,.20,1.205),(47.06,.20,1.205),(47.06,.20,1.725),(47.93,.20,1.725),(47.93,.20,1.345),(47.93,.20,1.60)])
    # Close the lid only after the part has entered the open foam cavity.
    lid=boxed['lid']
    startrot=lid.rotation_euler.copy()
    r=startrot.copy();r.x=-math.pi/2
    key(lid,'rotation_euler',frame(23),r);key(lid,'rotation_euler',frame(25.15),r)
    r.x=0;key(lid,'rotation_euler',frame(25.65),r)
    nod(packer,25.2)
    pose(cam,23,(51.6,-5.65,3.25),(48.0,.30,1.56),48)
    pose(cam,25.96,(50.9,-5.1,3.00),(48.1,.25,1.55),48)

    # Receipt: the same package identity is matched against the tablet history.
    r=receiving((72,0,0))
    receiver=character('Jordan | receiving employee',(71.38,.83,0),'receiving',yaw=.10)
    receiver['head'].rotation_euler.z=.85
    arrival=package('Same identified package | receipt',(71.3,.25,1.22),open=False)
    arrival['root'].rotation_euler.z=math.pi
    motion(arrival['root'],[(26,(70.6,.25,1.22)),(26.75,(71.5,.25,1.22)),(29.96,(71.5,.25,1.22))])
    rt=device('Receiving identity check tablet',(72.77,.00,1.86),width=1.55,height=1.06)
    screen_facing_staff(rt)
    rh=history('Receiving history matches package',rt['screen'],width=1.37,height=.90)
    icon('Record identity confirmation','check',(.55,.31,.18),rt['screen'],scale=.16)
    check=icon('Package ID match','check',(0,.15,.20),rt['screen'],scale=.34)
    appear(check,frame(27.45),frame(28))
    reach(receiver,'right',[26,26.8,27.0,27.15,27.3,27.45,27.65,27.8,28,29.96],[(71.5,.72,1.54),(71.5,.72,1.54),(71.5,.72,1.96),(72.25,.28,1.96),(72.25,.28,1.55),(72.25,.28,1.55),(72.25,.28,1.96),(71.5,.72,1.96),(71.5,.72,1.54),(71.5,.72,1.54)])
    nod(receiver,27.45)
    colleague=character('Receiving background colleague',(75,2.8,0),'technician',yaw=.2)
    activity(colleague,26,30)
    pose(cam,26,(74.5,3.25,3.15),(72.0,.18,1.65),42)
    pose(cam,27.6,(75.2,4.3,3.60),(72.0,.18,1.65),42)
    pose(cam,28,(75.35,4.55,3.68),(72.0,.18,1.65),42)
    pose(cam,29.96,(75.55,4.8,3.78),(72.0,.18,1.65),42)

    # Smooth action curves; cuts occur exactly at scene boundaries.
    for ob in bpy.data.objects:
        if ob.animation_data and ob.animation_data.action:
            for fc in ob.animation_data.action.fcurves:
                for k in fc.keyframe_points:
                    if fc.data_path.startswith('hide_'): k.interpolation='CONSTANT'
                    elif ob==cam and round(k.co.x) in (120,384,504,552,624): k.interpolation='CONSTANT'
                    else:
                        k.interpolation='BEZIER';k.handle_left_type='AUTO_CLAMPED';k.handle_right_type='AUTO_CLAMPED'
    if cam.data.animation_data:
        for fc in cam.data.animation_data.action.fcurves:
            for k in fc.keyframe_points:
                k.interpolation='CONSTANT' if round(k.co.x) in (120,384,504,552,624) else 'BEZIER'
                k.handle_left_type='AUTO_CLAMPED';k.handle_right_type='AUTO_CLAMPED'
    for t,label in [(0,'HONEYWELL AEROSPACE'),(5,'COMPONENT HISTORY'),(10,'PERMISSIONED BLOCKCHAIN'),(16,'GODIRECT TRADE'),(21,'REVIEW / ORDER / DISPATCH'),(26,'RECEIVE AND MATCH IDENTIFICATION')]:
        s.timeline_markers.new(label,frame=frame(t))
    s['production_note']='Original illustrative recreations. Network validation concerns submitted records; it does not certify maintenance or airworthiness.'
    s['component_identity']='One small silver cylindrical aircraft component; one blue band and rectangular identification plate.'
    s.render.filepath=str(BASE/'render'/'frame_')
    soundtrack=BASE/'delivery'/'soundtrack.wav'
    if soundtrack.exists():
        editor=s.sequence_editor_create()
        strip=editor.sequences.new_sound('Original instrumental music and synchronized effects',str(soundtrack),channel=1,frame_start=1)
    s.frame_set(1)
    bpy.ops.file.pack_all()
    if soundtrack.exists():strip.sound.filepath='//soundtrack.wav'
    bpy.ops.wm.save_as_mainfile(filepath=str(BASE/'delivery'/'Honeywell_Opening.blend'))
    return s

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--previews',action='store_true')
    parser.add_argument('--render',action='store_true');parser.add_argument('--start',type=int,default=1)
    parser.add_argument('--end',type=int,default=720);parser.add_argument('--step',type=int,default=1)
    args=parser.parse_args(sys.argv[sys.argv.index('--')+1:] if '--' in sys.argv else [])
    scene=build()
    if args.previews:
        scene.render.resolution_percentage=60
        for f in (48,190,336,465,589,681):
            scene.frame_set(f);scene.render.filepath=str(BASE/'render'/('preview_%03d.png'%f))
            bpy.ops.render.render(write_still=True)
    if args.render:
        scene.render.resolution_percentage=100;scene.frame_start=args.start;scene.frame_end=args.end;scene.frame_step=args.step
        scene.render.filepath=str(BASE/'render'/'frame_');bpy.ops.render.render(animation=True)
