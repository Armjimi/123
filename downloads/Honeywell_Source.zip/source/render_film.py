"""Render the saved scene with fast native-resolution edge antialiasing."""
import bpy, sys, time, argparse
from pathlib import Path
BASE=Path(__file__).resolve().parent.parent
p=argparse.ArgumentParser();p.add_argument('--benchmark',action='store_true')
p.add_argument('--step',type=int,default=2);p.add_argument('--start',type=int,default=1);p.add_argument('--end',type=int,default=720)
args=p.parse_args(sys.argv[sys.argv.index('--')+1:] if '--' in sys.argv else [])
s=bpy.context.scene;s.render.resolution_percentage=100
s.display.render_aa='FXAA';s.render.image_settings.compression=10
if args.benchmark:
    for f in (48,190):
        s.frame_set(f);s.render.filepath=str(BASE/'render'/f'native_test_{f}.png')
        t=time.monotonic();bpy.ops.render.render(write_still=True)
        print('NATIVE_FRAME_SECONDS',f,round(time.monotonic()-t,3),flush=True)
else:
    s.frame_start=1;s.frame_end=720;s.frame_step=1;s.frame_set(1)
    s.render.filepath=str(BASE/'render'/'frame_')
    bpy.ops.wm.save_as_mainfile(filepath=str(BASE/'delivery'/'Honeywell_Opening.blend'))
    s.frame_start=args.start;s.frame_end=args.end;s.frame_step=args.step
    bpy.ops.render.render(animation=True)
